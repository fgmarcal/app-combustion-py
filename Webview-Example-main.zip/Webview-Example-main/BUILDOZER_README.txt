# Requires internet permission

android.permissions = INTERNET
