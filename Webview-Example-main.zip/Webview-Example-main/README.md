Webview
=======

*An embedded Kivy Android web page viewer*

Provides full screen display of "https://" and "file://" urls. To close the viewer use the back gesture or the back button.

The buildozer options are documented in [BUILDOZER_README.txt](https://github.com/Android-for-Python/Webview-Example/blob/main/BUILDOZER_README.txt)


